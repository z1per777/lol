import http.server
import socketserver
import json
import urllib.parse
import time
import os
import re

# Путь к файлу логов
LOG_FILE = os.path.expanduser('~/server_logs.txt')
USERS_FILE = '/storage/emulated/0/BG/blockygo/users.json'

# Очистка логов
if os.path.exists(LOG_FILE):
    try:
        os.remove(LOG_FILE)
        print(f"Старый файл логов {LOG_FILE} удалён")
    except Exception as e:
        print(f"Ошибка удаления логов: {e}")

def log_to_file(message):
    try:
        with open(LOG_FILE, 'a') as f:
            timestamp = time.strftime('%Y-%m-%d %H:%M:%S')
            f.write(f"[{timestamp}] {message}\n")
        print(f"[{timestamp}] {message}")
    except Exception as e:
        print(f"Ошибка записи логов: {e}")

# База данных
users = {}
next_user_id = 1000000

# Загрузка пользователей
if os.path.exists(USERS_FILE):
    try:
        with open(USERS_FILE, 'r') as f:
            saved_data = json.load(f)
            users = saved_data['users']
            next_user_id = max(saved_data['next_user_id'], 1000001)
        log_to_file(f"Загружено {len(users)} пользователей из {USERS_FILE}")
    except Exception as e:
        log_to_file(f"Ошибка загрузки users.json: {e}")
else:
    log_to_file("Файл users.json не найден, создаётся новый")

def sync_users_from_file():
    global users, next_user_id
    if os.path.exists(USERS_FILE):
        try:
            with open(USERS_FILE, 'r') as f:
                saved_data = json.load(f)
                file_users = saved_data.get('users', {})
                file_next_user_id = saved_data.get('next_user_id', next_user_id)
                for account, file_user in file_users.items():
                    if account in users:
                        users[account].update(file_user)
                        log_to_file(f"Synced user {account} from file: {file_user}")
                    else:
                        users[account] = file_user
                        log_to_file(f"Added new user {account} from file: {file_user}")
                next_user_id = max(next_user_id, file_next_user_id)
        except Exception as e:
            log_to_file(f"Ошибка синхронизации users.json: {e}")

def save_users():
    try:
        sync_users_from_file()
        with open(USERS_FILE, 'w') as f:
            json.dump({'users': users, 'next_user_id': next_user_id}, f, indent=4)
        log_to_file("Пользователи сохранены в users.json")
    except Exception as e:
        log_to_file(f"Ошибка сохранения users.json: {e}")

def get_next_user_id():
    global next_user_id
    user_id = next_user_id
    next_user_id += 1
    save_users()
    return user_id

def generate_token(user_id):
    iat = int(time.time())
    exp = iat + 86400 * 10
    return f"eyJhbGciOiJIUzI1NiJ9.eyJqdGkiOiI{user_id}\",\"iat\":{iat},\"sub\":\"{time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(iat))}\",\"iss\":\"Sandbox-Security-Basic\",\"exp\":{exp}}}.fake_signature"

# Дефолтные списки игр
default_games = [
    {"gameId": "g2001", "name": "Classic Game", "iconUrl": "http://static.sandboxol.com/game/g2001.png", "version": "1.0", "isNewEngine": 0, "isUgc": 0, "regionId": "global", "roomAddr": "", "gameInstanceId": "", "isPrivateParty": 0, "appVersion": 3999, "mode": "classic"},
    {"gameId": "g2002", "name": "Tournament Game", "iconUrl": "http://static.sandboxol.com/game/g2002.png", "version": "1.0", "isNewEngine": 0, "isUgc": 0, "regionId": "global", "roomAddr": "", "gameInstanceId": "", "isPrivateParty": 0, "appVersion": 3999, "mode": "tournament"}
]
default_recent_games = [
    {"gameId": "g2001", "name": "Classic Game", "iconUrl": "http://static.sandboxol.com/game/g2001.png", "version": "1.0", "isNewEngine": 0, "isUgc": 0, "regionId": "global", "roomAddr": "", "gameInstanceId": "", "isPrivateParty": 0, "appVersion": 3999, "lastPlayed": "2025-08-14 11:00:00", "mode": "classic"}
]

class APIHandler(http.server.SimpleHTTPRequestHandler):
    def get_auth_token(self):
        auth = self.headers.get('Authorization') or self.headers.get('Access-Token')
        if auth and (auth.startswith('Bearer ') or auth.startswith('eyJhbGciOiJIUzI1NiJ9')):
            return auth.split(' ')[1] if auth.startswith('Bearer ') else auth
        return None

    def find_user_by_id(self, user_id):
        try:
            user_id = int(user_id)
            for user in users.values():
                if user.get('userId') == user_id:
                    return user
        except ValueError:
            return None
        return None

    def find_user_by_token(self, token):
        for user in users.values():
            if user.get('accessToken') == token:
                return user
        return None

    def ensure_user_games(self, user):
        if 'games' not in user or not user['games']:
            user['games'] = default_games
            log_to_file(f"Added default games to user {user['account']}: {user['games']}")
        if 'recentGames' not in user or not user['recentGames']:
            user['recentGames'] = default_recent_games
            log_to_file(f"Added default recentGames to user {user['account']}: {user['recentGames']}")
        save_users()

    def send_error(self, code, message=None):
        self.send_response(code)
        self.send_header('Content-type', 'application/json; charset=utf-8')
        self.end_headers()
        response = {"code": 0, "message": "FAILURE", "data": {"message": message or "Error"}}
        self.wfile.write(json.dumps(response).encode('utf-8'))
        log_to_file(f"Error {code}: {message}")

    def do_GET(self):
        parsed_path = urllib.parse.urlparse(self.path)
        path = parsed_path.path
        query = urllib.parse.parse_qs(parsed_path.query)
        log_to_file(f"GET request: {path} with headers: {dict(self.headers)}, query: {query}")

        # Извлечение friendId или otherId из пути
        friend_id_match = re.match(r'^/friend/api/v[12]/friends/(\d+)(/gaming)?$', path)
        decoration_id_match = re.match(r'^/decoration/api/v1/decorations/(\d+)/using$', path)

        if friend_id_match:
            friend_id = friend_id_match.group(1)
            is_gaming = bool(friend_id_match.group(2))
            token = self.get_auth_token()
            if not token:
                self.send_error(401, "Отсутствует токен")
                return
            requesting_user = self.find_user_by_token(token)
            if not requesting_user:
                self.send_error(401, "Недействительный токен")
                return
            friend = self.find_user_by_id(friend_id)
            if not friend:
                self.send_error(404, f"Пользователь с friendId {friend_id} не найден")
                return
            language = self.headers.get('language', 'en')
            self.send_response(200)
            self.send_header('Content-type', 'application/json; charset=utf-8')
            self.end_headers()
            if is_gaming:
                # /friend/api/v1/friends/{friendId}/gaming
                response = {
                    "code": 1,
                    "message": "SUCCESS",
                    "data": {
                        "status": "offline",  # Заглушка, так как нет данных об игровой активности
                        "gameId": None,
                        "lastActive": time.strftime('%Y-%m-%d %H:%M:%S')
                    }
                }
            else:
                # /friend/api/v2/friends/{friendId}
                response = {
                    "code": 1,
                    "message": "SUCCESS",
                    "data": {
                        "userId": friend['userId'],
                        "nickName": friend['nickName'],
                        "sex": friend['sex'],
                        "picUrl": friend['picUrl'],
                        "telephone": friend['telephone'],
                        "birthday": friend['birthday'],
                        "details": friend['details'],
                        "vip": friend['vip'],
                        "expireDate": friend['expireDate']
                    }
                }
            self.wfile.write(json.dumps(response).encode('utf-8'))
            log_to_file(f"Response to {path}: {response}")
            return

        elif decoration_id_match:
            other_id = decoration_id_match.group(1)
            token = self.get_auth_token()
            if not token:
                self.send_error(401, "Отсутствует токен")
                return
            requesting_user = self.find_user_by_token(token)
            if not requesting_user:
                self.send_error(401, "Недействительный токен")
                return
            friend = self.find_user_by_id(other_id)
            if not friend:
                self.send_error(404, f"Пользователь с otherId {other_id} не найден")
                return
            language = self.headers.get('language', 'en')
            self.send_response(200)
            self.send_header('Content-type', 'application/json; charset=utf-8')
            self.end_headers()
            response = {
                "code": 1,
                "message": "SUCCESS",
                "data": []  # Заглушка, так как нет данных о декорациях
            }
            self.wfile.write(json.dumps(response).encode('utf-8'))
            log_to_file(f"Response to {path}: {response}")
            return

        elif path == '/user/api/v1/user/nickname/exist':
            nick = query.get('nickName', [None])[0]
            if not nick:
                self.send_error(400, "Отсутствует nickName")
                return
            exists = any(u.get('nickName') == nick for u in users.values())
            self.send_response(200)
            self.send_header('Content-type', 'application/json; charset=utf-8')
            self.end_headers()
            response = {"code": 1, "message": "SUCCESS" if not exists else "EXISTS", "data": None if not exists else True}
            self.wfile.write(json.dumps(response).encode('utf-8'))
            log_to_file(f"Response to {path}: {response}")
            return

        elif path == '/user/api/v1/app/auth-token':
            token = self.get_auth_token()
            user_id = self.headers.get('bmg-user-id', '')
            device_id = self.headers.get('bmg-device-id', '')
            log_to_file(f"Auth-token check: token={token}, user_id={user_id}, device_id={device_id}")
            self.send_response(200)
            self.send_header('Content-type', 'application/json; charset=utf-8')
            self.end_headers()
            response = {"code": 1, "message": "SUCCESS", "data": None}
            self.wfile.write(json.dumps(response).encode('utf-8'))
            log_to_file(f"Response to {path}: {response}")
            return

        elif path == '/user/api/v1/users/device/token':
            token = self.get_auth_token()
            device_id = self.headers.get('bmg-device-id', '')
            log_to_file(f"Device token: token={token}, device_id={device_id}")
            self.send_response(200)
            self.send_header('Content-type', 'application/json; charset=utf-8')
            self.end_headers()
            response = {"code": 1, "message": "SUCCESS", "data": {"deviceToken": token or ""}}
            self.wfile.write(json.dumps(response).encode('utf-8'))
            log_to_file(f"Response to {path}: {response}")
            return

        elif path == '/user/api/v1/user/info':
            token = self.get_auth_token()
            if not token:
                self.send_error(401, "Отсутствует токен")
                return
            user = self.find_user_by_token(token)
            if not user:
                self.send_error(401, "Недействительный токен")
                return
            self.ensure_user_games(user)
            self.send_response(200)
            self.send_header('Content-type', 'application/json; charset=utf-8')
            self.end_headers()
            response = {"code": 1, "message": "SUCCESS", "data": {
                "sex": user['sex'],
                "nickName": user['nickName'],
                "picUrl": user['picUrl'] or "http://static.sandboxol.com/sandbox/activity/login/login_male_pic_1.png",
                "birthday": user['birthday'],
                "details": user['details'],
                "userId": user['userId'],
                "vip": user['vip'],
                "expireDate": user['expireDate'],
                "language": None
            }}
            self.wfile.write(json.dumps(response).encode('utf-8'))
            log_to_file(f"Response to {path}: {response}")
            return

        elif path == '/config/files/blockmods-config' or path == '/config/files/blockmods-config-v1':
            config_data = {
                "code": 1,
                "message": "OK",
                "data": {
                    "isShowThirdPart": False,
                    "isOpenUpdateSO": False,
                    "isOpenMorePay": False,
                    "isShowShare": True,
                    "isShowCampaign": True,
                    "isShowChest": True,
                    "isShowHallowmasChest": False,
                    "isShowActivity": False,
                    "activityVersionCode": 999.0,
                    "isShowUniversalActivity": False,
                    "universalActivityVersionCode": 892.0,
                    "isShowPartyInvite": True,
                    "isShowFriendMatch": True,
                    "isShowDressRecommend": True,
                    "dailyShareVersionCode": 999.0,
                    "activityUrl": "https://www.blockmango.net/TEST.html",
                    "gratitudeUrl": "",
                    "newGratitudeUrl": "https://www.blockmango.net/gratitude.html",
                    "isNeedSystemAnnouncement": True,
                    "isNeedStopServiceAnnouncement": False,
                    "isSilentDownload": False,
                    "isShowGameGuide": False,
                    "isOpenVideoSubmitActivity": False,
                    "videoSubmitActivityCode": 9999.0,
                    "isShowMainGuide": False,
                    "adsConfig": {
                        "mainAdsCD": 300.0,
                        "mainAdsGray": 0.0,
                        "gameDetailAdsCD": 1800.0,
                        "gameDetailAdsGray": 0.0,
                        "midwayAdGray": 0.0,
                        "finalAdGray": 0.0,
                        "hallAdGray": 0.0,
                        "enterDetailGray": 0.0,
                        "clickTabGray": 0.0
                    },
                    "specialAdsConfig": {
                        "mainAdsCD": 300.0,
                        "mainAdsGray": 0.0,
                        "gameDetailAdsCD": 7200.0,
                        "gameDetailAdsGray": 0.0,
                        "midwayAdGray": 0.0,
                        "finalAdGray": 0.0,
                        "hallAdGray": 0.0,
                        "enterDetailGray": 0.0,
                        "clickTabGray": 0.0
                    },
                    "isOpenMTP": True,
                    "WhitelistLink": [
                        "https://www.blockmango.net/",
                        "https://www.blockmango.cn/",
                        "https://depz1z6xv9td2.cloudfront.net/",
                        "http://192.168.2.13:9918/",
                        "http://static.blockmango.cn/",
                        "http://depz1z6xv9td2.cloudfront.net/",
                        "https://static.blockmango.cn/"
                    ],
                    "downloadConfig": {
                        "reconnectCount": 4.0,
                        "rateMultiple": 3.0,
                        "slowPeriod": 2.147483647E9,
                        "startCountingTime": 1000.0
                    },
                    "downloadGames": ["g1046"],
                    "reportInterval": 60.0,
                    "pingReportInterval": 60.0,
                    "v2CommonGameList": [
                        "g2001", "g2002", "g2003", "g2004", "g2005", "g2006", "g2007", "g2008", "g2009",
                        "g2010", "g2011", "g2012", "g2013", "g2014", "g2015", "g2016", "g2017", "g2018",
                        "g2019", "g2022", "g2024", "g20000031"
                    ]
                }
            }
            self.send_response(200)
            self.send_header('Content-type', 'application/json; charset=utf-8')
            self.end_headers()
            self.wfile.write(json.dumps(config_data).encode('utf-8'))
            log_to_file(f"Response to {path}: {config_data}")
            return

        elif path == '/friend/api/v1/friends/follow':
            language = self.headers.get('language', 'en')
            page_no = int(query.get('pageNo', ['0'])[0])
            page_size = int(query.get('pageSize', ['20'])[0])
            self.send_response(200)
            self.send_header('Content-type', 'application/json; charset=utf-8')
            self.end_headers()
            response = {"code": 1, "message": "SUCCESS", "data": {"friends": [], "total": 0, "pageNo": page_no, "pageSize": page_size}}
            self.wfile.write(json.dumps(response).encode('utf-8'))
            log_to_file(f"Response to {path}: {response}")
            return

        elif path == '/game/api/v1/game/revision/list/more':
            token = self.get_auth_token()
            user = self.find_user_by_token(token) if token else None
            if user:
                self.ensure_user_games(user)
                games = user.get('games', default_games)
            else:
                games = default_games
            page_no = int(query.get('pageNo', ['0'])[0])
            page_size = int(query.get('pageSize', ['15'])[0])
            start = page_no * page_size
            end = start + page_size
            self.send_response(200)
            self.send_header('Content-type', 'application/json; charset=utf-8')
            self.end_headers()
            response = {
                "code": 1,
                "message": "SUCCESS",
                "data": {
                    "list": games[start:end],
                    "total": len(games),
                    "pageNo": page_no,
                    "pageSize": page_size
                }
            }
            self.wfile.write(json.dumps(response).encode('utf-8'))
            log_to_file(f"Response to {path}: {response}")
            return

        elif path == '/game/api/v1/game/revision/list/recommend':
            token = self.get_auth_token()
            user = self.find_user_by_token(token) if token else None
            if user:
                self.ensure_user_games(user)
                games = user.get('games', default_games)
            else:
                games = [
                    {"gameId": "g1048", "name": "Recommended Game 1", "iconUrl": "http://staticgs.sandboxol.com/sandbox/games/images/g1048-1710474142954.png", "version": "1.0", "isNewEngine": 0, "isUgc": 0, "regionId": "global", "roomAddr": "", "gameInstanceId": "", "isPrivateParty": 0, "appVersion": 3999, "mode": "tournament"},
                    {"gameId": "g1008", "name": "Recommended Game 2", "iconUrl": "http://staticgs.sandboxol.com/sandbox/games/images/g1008-1684547322902.png", "version": "1.0", "isNewEngine": 0, "isUgc": 0, "regionId": "global", "roomAddr": "", "gameInstanceId": "", "isPrivateParty": 0, "appVersion": 3999, "mode": "tournament"}
                ]
            self.send_response(200)
            self.send_header('Content-type', 'application/json; charset=utf-8')
            self.end_headers()
            response = {
                "code": 1,
                "message": "SUCCESS",
                "data": games
            }
            self.wfile.write(json.dumps(response).encode('utf-8'))
            log_to_file(f"Response to {path}: {response}")
            return

        elif path == '/game/api/v1/games/playlist/recently':
            token = self.get_auth_token()
            user = self.find_user_by_token(token) if token else None
            if user:
                self.ensure_user_games(user)
                games = user.get('recentGames', default_recent_games)
            else:
                games = default_recent_games
            self.send_response(200)
            self.send_header('Content-type', 'application/json; charset=utf-8')
            self.end_headers()
            response = {
                "code": 1,
                "message": "SUCCESS",
                "data": games
            }
            self.wfile.write(json.dumps(response).encode('utf-8'))
            log_to_file(f"Response to {path}: {response}")
            return

        elif path == '/user/api/v2/users/verify/user/security/settings':
            token = self.get_auth_token()
            if not token:
                self.send_error(401, "Отсутствует токен")
                return
            user = self.find_user_by_token(token)
            if not user:
                self.send_error(401, "Недействительный токен")
                return
            self.send_response(200)
            self.send_header('Content-type', 'application/json; charset=utf-8')
            self.end_headers()
            response = {"code": 1, "message": "SUCCESS", "data": {"hasPassword": user['hasPassword'], "email": None, "phone": user['telephone']}}
            self.wfile.write(json.dumps(response).encode('utf-8'))
            log_to_file(f"Response to {path}: {response}")
            return

        elif path == '/decoration/api/v1/new/decorations/check/resource':
            language = self.headers.get('language', 'en')
            res_version = query.get('resVersion', [0])[0]
            engine_version = query.get('engineVersion', [0])[0]
            self.send_response(200)
            self.send_header('Content-type', 'application/json; charset=utf-8')
            self.end_headers()
            response = {"code": 1, "message": "SUCCESS", "data": []}
            self.wfile.write(json.dumps(response).encode('utf-8'))
            log_to_file(f"Response to {path}: {response}")
            return

        elif path == '/msg/api/v1/msg/group/chat/list':
            page_no = int(query.get('pageNo', ['0'])[0])
            page_size = int(query.get('pageSize', ['200'])[0])
            self.send_response(200)
            self.send_header('Content-type', 'application/json; charset=utf-8')
            self.end_headers()
            response = {"code": 1, "message": "SUCCESS", "data": {"list": [], "total": 0, "pageNo": page_no, "pageSize": page_size}}
            self.wfile.write(json.dumps(response).encode('utf-8'))
            log_to_file(f"Response to {path}: {response}")
            return

        elif path == '/clan/api/v1/clan/tribe/id':
            self.send_response(200)
            self.send_header('Content-type', 'application/json; charset=utf-8')
            self.end_headers()
            response = {"code": 1, "message": "SUCCESS", "data": None}
            self.wfile.write(json.dumps(response).encode('utf-8'))
            log_to_file(f"Response to {path}: {response}")
            return

        elif path == '/config/files/blockymods-check-version':
            self.send_response(200)
            self.send_header('Content-type', 'application/json; charset=utf-8')
            self.end_headers()
            response = {"code": 1, "message": "SUCCESS", "data": {"version": "1.0", "forceUpdate": False}}
            self.wfile.write(json.dumps(response).encode('utf-8'))
            log_to_file(f"Response to {path}: {response}")
            return

        elif path == '/activity/api/v1/signIn':
            self.send_response(200)
            self.send_header('Content-type', 'application/json; charset=utf-8')
            self.end_headers()
            response = {"code": 1, "message": "SUCCESS", "data": None}
            self.wfile.write(json.dumps(response).encode('utf-8'))
            log_to_file(f"Response to {path}: {response}")
            return

        elif path == '/pay/api/v1/wealth/user':
            token = self.get_auth_token()
            if not token:
                self.send_error(401, "Отсутствует токен")
                return
            user = self.find_user_by_token(token)
            if not user:
                self.send_error(401, "Недействительный токен")
                return
            self.send_response(200)
            self.send_header('Content-type', 'application/json; charset=utf-8')
            self.end_headers()
            response = {
                "code": 1,
                "message": "SUCCESS",
                "data": {
                    "diamonds": user.get('diamonds', 0),
                    "golds": user.get('golds', 0),
                    "vip": user.get('vip', 0)
                }
            }
            self.wfile.write(json.dumps(response).encode('utf-8'))
            log_to_file(f"Response to {path}: {response}")
            return

        elif path.startswith('/game/api/v1/games/update/list/'):
            token = self.get_auth_token()
            user = self.find_user_by_token(token) if token else None
            if not user:
                self.send_error(401, "Недействительный токен")
                return
            self.send_response(200)
            self.send_header('Content-type', 'application/json; charset=utf-8')
            self.end_headers()
            response = {"code": 1, "message": "SUCCESS", "data": {}}
            self.wfile.write(json.dumps(response).encode('utf-8'))
            log_to_file(f"Response to {path}: {response}")
            return

        elif path == '/activity/api/v2/collect/exchange/card/combine':
            self.send_response(200)
            self.send_header('Content-type', 'application/json; charset=utf-8')
            self.end_headers()
            response = {"code": 1, "message": "SUCCESS", "data": None}
            self.wfile.write(json.dumps(response).encode('utf-8'))
            log_to_file(f"Response to {path}: {response}")
            return

        elif path == '/mailbox/api/v1/mail/new':
            self.send_response(200)
            self.send_header('Content-type', 'application/json; charset=utf-8')
            self.end_headers()
            response = {"code": 1, "message": "SUCCESS", "data": {"newMailCount": 0}}
            self.wfile.write(json.dumps(response).encode('utf-8'))
            log_to_file(f"Response to {path}: {response}")
            return

        elif path == '/activity/api/v2/activity/title':
            self.send_response(200)
            self.send_header('Content-type', 'application/json; charset=utf-8')
            self.end_headers()
            response = {"code": 1, "message": "SUCCESS", "data": []}
            self.wfile.write(json.dumps(response).encode('utf-8'))
            log_to_file(f"Response to {path}: {response}")
            return

        self.send_error(404, "Ресурс не найден")

    def do_POST(self):
        parsed_path = urllib.parse.urlparse(self.path)
        path = parsed_path.path
        query = urllib.parse.parse_qs(parsed_path.query)
        content_length = int(self.headers['Content-Length'] or 0)
        post_data = self.rfile.read(content_length) if content_length > 0 else b''
        data = {}
        device_id = self.headers.get('deviceId', '') or self.headers.get('bmg-device-id', '')
        if content_length > 0:
            try:
                data = json.loads(post_data)
            except json.JSONDecodeError:
                self.send_error(400, "Неверный формат JSON")
                return

        log_to_file(f"POST request: {path} with headers: {dict(self.headers)}, data: {data}, query: {query}")

        if path == '/user/api/v2/app/login':
            uid = data.get('uid')
            password = data.get('password')
            app_type = data.get('appType')
            has_password = data.get('hasPassword', False)
            if not uid or not app_type:
                self.send_error(400, "Отсутствует uid или appType")
                return
            if uid not in users:
                user_id = get_next_user_id()
                token = generate_token(user_id)
                users[uid] = {
                    'userId': user_id,
                    'accessToken': token,
                    'account': uid,
                    'hasPassword': has_password,
                    'password': password if has_password else None,
                    'nickName': '',
                    'sex': 1,
                    'picUrl': 'http://static.sandboxol.com/sandbox/activity/login/login_male_pic_1.png',
                    'telephone': '',
                    'birthday': '',
                    'details': '',
                    'diamonds': 500,
                    'golds': 100,
                    'vip': 3,
                    'expireDate': '',
                    'deviceId': device_id,
                    'games': default_games,
                    'recentGames': default_recent_games
                }
                log_to_file(f"Создан новый пользователь: {users[uid]}")
                save_users()
            user = users[uid]
            if has_password:
                log_to_file(f"ВНИМАНИЕ: Проверка пароля отключена для uid={uid}")
                # Временная заглушка: игнорируем пароль, так как он зашифрован
            user['accessToken'] = generate_token(user['userId'])
            user['deviceId'] = device_id
            save_users()
            self.send_response(200)
            self.send_header('Content-type', 'application/json; charset=utf-8')
            self.end_headers()
            response = {
                "code": 1,
                "message": "SUCCESS",
                "data": {
                    "userId": user['userId'],
                    "accessToken": user['accessToken'],
                    "account": user['account'],
                    "sex": user['sex'],
                    "nickName": user['nickName'],
                    "picUrl": user['picUrl'],
                    "telephone": user['telephone'],
                    "birthday": user['birthday'],
                    "details": user['details'],
                    "diamonds": user['diamonds'],
                    "golds": user['golds'],
                    "vip": user['vip'],
                    "expireDate": user['expireDate'],
                    "hasPassword": user['hasPassword']
                }
            }
            self.wfile.write(json.dumps(response).encode('utf-8'))
            log_to_file(f"Response to {path}: {response}")
            return

        elif path == '/user/api/v1/account/invalid/check':
            account = query.get('account', [None])[0]
            if not account:
                self.send_error(400, "Отсутствует account")
                return
            self.send_response(200)
            self.send_header('Content-type', 'application/json; charset=utf-8')
            self.end_headers()
            available = account not in users
            response = {"code": 1, "message": None, "data": available}
            self.wfile.write(json.dumps(response).encode('utf-8'))
            log_to_file(f"Response to {path}: {response}")
            return

        elif path == '/user/api/v1/user/nickname/exist':
            nick = query.get('nickName', [None])[0]
            if not nick:
                self.send_error(400, "Отсутствует nickName")
                return
            exists = any(u.get('nickName') == nick for u in users.values())
            self.send_response(200)
            self.send_header('Content-type', 'application/json; charset=utf-8')
            self.end_headers()
            response = {"code": 1, "message": "SUCCESS" if not exists else "EXISTS", "data": None if not exists else True}
            self.wfile.write(json.dumps(response).encode('utf-8'))
            log_to_file(f"Response to {path}: {response}")
            return

        elif path == '/user/api/v1/user/mac/id':
            uuid = query.get('uuid', [None])[0]
            app_type = query.get('appType', ['android'])[0]
            if not uuid or app_type != 'android':
                self.send_error(400, "Неверный uuid или appType")
                return
            self.send_response(200)
            self.send_header('Content-type', 'application/json; charset=utf-8')
            self.end_headers()
            response = {"code": 1, "message": "SUCCESS", "data": None}
            self.wfile.write(json.dumps(response).encode('utf-8'))
            log_to_file(f"Response to {path}: {response}")
            return

        elif path == '/user/api/v1/app/renew':
            account = query.get('account', [None])[0]
            device_id = self.headers.get('bmg-device-id', '')
            log_to_file(f"Processing /app/renew: account={account}, device_id={device_id}")
            if not account or not device_id:
                self.send_error(400, "Отсутствует account или device_id")
                return
            if account not in users:
                user_id = get_next_user_id()
                token = generate_token(user_id)
                users[account] = {
                    'userId': user_id,
                    'accessToken': token,
                    'account': account,
                    'hasPassword': False,
                    'password': None,
                    'nickName': '',
                    'sex': 1,
                    'picUrl': 'http://static.sandboxol.com/sandbox/activity/login/login_male_pic_1.png',
                    'telephone': '',
                    'birthday': '',
                    'details': '',
                    'diamonds': 0,
                    'golds': 0,
                    'vip': 0,
                    'expireDate': '',
                    'deviceId': device_id,
                    'games': default_games,
                    'recentGames': default_recent_games
                }
                log_to_file(f"Created new user: {users[account]}")
                save_users()
            user = users[account]
            self.ensure_user_games(user)
            user['accessToken'] = generate_token(user['userId'])
            user['deviceId'] = device_id
            save_users()
            self.send_response(200)
            self.send_header('Content-type', 'application/json; charset=utf-8')
            self.end_headers()
            response = {"code": 1, "message": None, "data": {"userId": user['userId'], "accessToken": user['accessToken']}}
            self.wfile.write(json.dumps(response).encode('utf-8'))
            log_to_file(f"Response to {path}: {response}")
            return

        elif path == '/user/api/v2/app/set-password':
            account = data.get('account')
            password = data.get('password')
            confirm = data.get('confirmPassword')
            client_user_id = data.get('userId')
            log_to_file(f"Set-password: account={account}, password={password}, confirmPassword={confirm}, client_user_id={client_user_id}")
            if not account or account not in users:
                self.send_error(400, "Неверный account")
                return
            if not password:
                self.send_error(400, "Отсутствует пароль")
                return
            user = users[account]
            log_to_file(f"Using server userId: {user['userId']} for account {account}")
            user['password'] = password
            user['hasPassword'] = True
            save_users()
            self.send_response(200)
            self.send_header('Content-type', 'application/json; charset=utf-8')
            self.end_headers()
            response = {"code": 1, "message": "SUCCESS", "data": None}
            self.wfile.write(json.dumps(response).encode('utf-8'))
            log_to_file(f"Response to {path}: {response}")
            return

        elif path == '/user/api/v1/user/register':
            token = self.get_auth_token()
            if not token:
                self.send_error(401, "Отсутствует токен")
                return
            user = self.find_user_by_token(token)
            if not user or not user['hasPassword']:
                self.send_error(400, "Требуется установка пароля")
                return
            invite = data.get('inviteCode', '')
            nick = data.get('nickName')
            sex = data.get('sex', 1)
            log_to_file(f"Register: nickName={nick}, sex={sex}, inviteCode={invite}, userId={user['userId']}")
            if not nick:
                self.send_error(400, "Отсутствует nickName")
                return
            if any(u.get('nickName') == nick for u in users.values() if u != user):
                self.send_error(400, "Никнейм уже существует")
                return
            user['nickName'] = nick
            user['sex'] = sex
            user['picUrl'] = "http://static.sandboxol.com/sandbox/activity/login/login_male_pic_1.png"
            user['accessToken'] = generate_token(user['userId'])
            self.ensure_user_games(user)
            save_users()
            response_data = {
                "userId": user['userId'],
                "accessToken": user['accessToken'],
                "account": user['account'],
                "sex": user['sex'],
                "nickName": user['nickName'],
                "picUrl": user['picUrl'],
                "telephone": user['telephone'],
                "birthday": user['birthday'],
                "details": user['details'],
                "diamonds": user['diamonds'],
                "golds": user['golds'],
                "vip": user['vip'],
                "expireDate": user['expireDate'],
                "hasPassword": user['hasPassword']
            }
            self.send_response(200)
            self.send_header('Content-type', 'application/json; charset=utf-8')
            self.end_headers()
            response = {"code": 1, "message": "SUCCESS", "data": response_data}
            self.wfile.write(json.dumps(response).encode('utf-8'))
            log_to_file(f"Response to {path}: {response}")
            return

        elif path == '/user/api/v1/user/details/info':
            token = self.get_auth_token()
            if not token:
                self.send_error(401, "Отсутствует токен")
                return
            user = self.find_user_by_token(token)
            if not user:
                self.send_error(401, "Недействительный токен")
                return
            self.ensure_user_games(user)
            self.send_response(200)
            self.send_header('Content-type', 'application/json; charset=utf-8')
            self.end_headers()
            response = {"code": 1, "message": "SUCCESS", "data": {
                "userId": user['userId'],
                "sex": user['sex'],
                "nickName": user['nickName'],
                "picUrl": user['picUrl'],
                "telephone": user['telephone'],
                "email": None,
                "birthday": user['birthday'],
                "details": user['details'],
                "diamonds": user['diamonds'],
                "golds": user['golds'],
                "vip": user['vip'],
                "expireDate": user['expireDate'],
                "account": user['account'],
                "hasPassword": user['hasPassword'],
                "platform": "app"
            }}
            self.wfile.write(json.dumps(response).encode('utf-8'))
            log_to_file(f"Response to {path}: {response}")
            return

        elif path == '/datareport/api/v1/funnel/event/report' or path == '/datareport/api/v1/event/report':
            if not device_id:
                self.send_error(400, "Отсутствует deviceId")
                return
            self.send_response(200)
            self.send_header('Content-type', 'application/json; charset=utf-8')
            self.end_headers()
            response = {"code": 1, "message": "SUCCESS", "data": None}
            self.wfile.write(json.dumps(response).encode('utf-8'))
            log_to_file(f"Response to {path}: {response}")
            return

        elif path == '/user/api/v1/user/daily/life/info':
            self.send_response(200)
            self.send_header('Content-type', 'application/json; charset=utf-8')
            self.end_headers()
            response = {"code": 1, "message": "SUCCESS", "data": {"dailyTasks": [], "lifeTasks": []}}
            self.wfile.write(json.dumps(response).encode('utf-8'))
            log_to_file(f"Response to {path}: {response}")
            return

        elif path == '/user/api/v1/user/language':
            token = self.get_auth_token()
            if not token:
                self.send_error(401, "Отсутствует токен")
                return
            user = self.find_user_by_token(token)
            if not user:
                self.send_error(401, "Недействительный токен")
                return
            language = query.get('language', ['en'])[0]
            user['language'] = language
            save_users()
            self.send_response(200)
            self.send_header('Content-type', 'application/json; charset=utf-8')
            self.end_headers()
            response = {"code": 1, "message": "SUCCESS", "data": None}
            self.wfile.write(json.dumps(response).encode('utf-8'))
            log_to_file(f"Response to {path}: {response}")
            return

        self.send_error(404, "Ресурс не найден")

    def do_PUT(self):
        parsed_path = urllib.parse.urlparse(self.path)
        path = parsed_path.path
        query = urllib.parse.parse_qs(parsed_path.query)
        content_length = int(self.headers['Content-Length'] or 0)
        put_data = self.rfile.read(content_length) if content_length > 0 else b''
        data = {}
        if content_length > 0:
            try:
                data = json.loads(put_data)
            except json.JSONDecodeError:
                self.send_error(400, "Неверный формат JSON")
                return

        log_to_file(f"PUT request: {path} with headers: {dict(self.headers)}, data: {data}, query: {query}")

        if path == '/game/api/v1/games/engine':
            engine_version = query.get('engineVersion', [None])[0]
            new_engine_version = query.get('newEngineVersion', [None])[0]
            if not engine_version or not new_engine_version:
                self.send_error(400, "Отсутствует engineVersion или newEngineVersion")
                return
            self.send_response(200)
            self.send_header('Content-type', 'application/json; charset=utf-8')
            self.end_headers()
            response = {"code": 1, "message": "SUCCESS", "data": None}
            self.wfile.write(json.dumps(response).encode('utf-8'))
            log_to_file(f"Response to {path}: {response}")
            return

        elif path == '/user/api/v1/user/device/id':
            token = self.get_auth_token()
            if not token:
                self.send_error(401, "Отсутствует токен")
                return
            user = self.find_user_by_token(token)
            if not user:
                self.send_error(401, "Недействительный токен")
                return
            device_id = self.headers.get('bmg-device-id', '') or data.get('deviceId', '')
            if not device_id:
                self.send_error(400, "Отсутствует device_id")
                return
            user['deviceId'] = device_id
            save_users()
            self.send_response(200)
            self.send_header('Content-type', 'application/json; charset=utf-8')
            self.end_headers()
            response = {"code": 1, "message": "SUCCESS", "data": None}
            self.wfile.write(json.dumps(response).encode('utf-8'))
            log_to_file(f"Response to {path}: {response}")
            return

        self.send_error(404, "Ресурс не найден")

# Запуск
PORT = 25763
with socketserver.TCPServer(("", PORT), APIHandler) as httpd:
    log_to_file(f"Сервер запущен на порту {PORT}")
    print(f"Сервер на порту {PORT}")
    httpd.serve_forever()